# Neuron-Video Chat with WebRTC and Firebase

## Usage

Update the firebase project config in the main.js file. 

```
git clone <this-repo>
npm install

npm run dev
```
